<template>
  <div class="detail-base-info">
    <h5>
      {{goods.title}}
    </h5>

    <div class="price">
      <span >{{goods.price}}</span>
      <span >{{goods.oldPrice}}</span>
      <span >{{goods.discountDesc}}</span>
    </div>

    <div >{{goods.columns }}</div>
    <div >{{goods.services }}</div>
    <div class="services" v-if="goods.columns && goods.services && goods.services.length && goods.columns.length">


      <div >{{goods.columns && goods.columns[0]}}</div>
      <div>{{goods.columns && goods.columns[1]}}</div>
      <div>{{goods.services && goods.services[3].name}}</div>
    </div>
<!--    <div class="services" v-if="goods.services && goods.services.length">-->
<!--      <div v-for="item in goods.services.slice(0,3)" >-->
<!--        <img :src="item.icon"/>-->
<!--        <span>{{item.name}}</span>-->
<!--      </div>-->
<!--    </div>-->
  </div>
</template>

<script>
  export default {
    name: "DetailBaseInfo",
    props: {
      goods: {
        type: Object,
        default(){
          return {}
        }
      }
    },
    mounted() {
      console.log(this.goods);
      console.log(this.goods.services);
      console.log(this.goods.columns);
    }
  }
</script>

<style scoped>
.detail-base-info h5{
  padding:0 5px;
}
.price{
  padding: 8px 4px;
}
  .price span:nth-child(1){
    color: var(--color-high-text);
    font-size: 18px;
    font-weight: bold;
    letter-spacing: 1px;
    padding: 0 6px;
  }
.price span:nth-child(2){
  color: #999;
  font-size: 12px;
  padding: 0 6px;
  text-decoration:line-through;
}
.price span:nth-child(3){
  color:#fff;
  font-size: 12px;
  padding:2px 4px;
  border-radius: 10px;
  background: var(--color-high-text);
  position: relative;
  top: -8px;
}
  .services{
    display: flex;
    color: #999;
    font-size: 12px;
    margin: 0 6px;
    padding: 10px 0;
    text-align: center;
   justify-content: space-between;
    border-bottom: 1px solid #eee;
  }
.services img{
  vertical-align: middle;
  height: 14px;
}
</style>
