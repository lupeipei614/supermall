<template>
  <div>
   <detail-nav-bar/>
    <detail-swiper :swiper-slides="topImages"/>
    <detail-base-info :goods="goods" />
  </div>
</template>

<script>
  import DetailNavBar from "./childCmps/DetailNavBar";
  import {getDetail,Goods} from "network/detail";
  import DetailSwiper from "./childCmps/DetailSwiper";
  import DetailBaseInfo from "./childCmps/DetailBaseInfo";

  export default {
    name: "Detail",
    components: {
      DetailSwiper,
      DetailNavBar,
      DetailBaseInfo
    },
    data(){
      return {
        iid: null,
        topImages: [],
        goods: {
          type: Object,
          default(){
            return {}
          }
        }
      }
    },
    created() {
      this.iid = this.$route.params.iid
      getDetail(this.iid).then(res => {
        // console.log(res.result);
        const data = res.result
        this.topImages = data.itemInfo.topImages
        //console.log(this.topImages)
        this.goods = new Goods(data.columns,data.itemInfo, data.shopInfo.services)
        // console.log(typeof this.goods);
      })

    }
  }
</script>

<style scoped>

</style>
