<template>
  <div>
    <a href="https://act.mogujie.com/zzlx67">
      <img src="~assets/img/home/recommend_bg.jpg" width="100%"/>
    </a>
  </div>
</template>

<script>
  export default {
    name: "Feature"
  }
</script>

<style scoped>

</style>
