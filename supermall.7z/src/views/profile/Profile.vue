<template>
  <div>我的内容</div>
</template>

<script>
  export default {
    name: "Profile"
  }
</script>

<style scoped>

</style>
