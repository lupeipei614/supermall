<template>
  <div>购物车内容</div>
</template>

<script>
  export default {
    name: "Cart"
  }
</script>

<style scoped>

</style>
