<template>
  <div class="goods-list-item">
    <img :src="goodsItem.show.img" @load="imgLoad" @click="itemClick"/>
    <p>{{goodsItem.title}}</p>
    <span>{{goodsItem.price}}</span>
    <span>{{goodsItem.cfav}}</span>
  </div>
</template>

<script>
  export default {
    name: "GoodsListItem",
    props: {
      goodsItem: {
        type: Object,
        default(){
          return {}
        }
      }
    },
    methods: {
      imgLoad(){
        this.$bus.$emit('itemImgLoad')
      },
      itemClick(){

        this.$router.push('/detail/' + this.goodsItem.iid)
      }
    }
  }
</script>

<style scoped>
  .goods-list-item{
    padding-bottom: 40px;

    width: 50%;
    text-align: center;
  }
  .goods-list-item img{
    border-radius: 5px;
    width: 96%;
  }
  .goods-list-item p{
    font-size: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 2px 6px;
  }
</style>
