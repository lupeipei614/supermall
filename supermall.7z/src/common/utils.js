export function debounce(func, delay){
  let timer = null
  return function(...args){
    if(timer) clearTimeout(timer)
    timer = setTimeout(() => {
      //console.log(func);
      func.apply(this,args)
    },500)

  }
}
